const classCheckEditor = require('./ckeditor');

classCheckEditor.A.prototype.cleanup = function() {
    
}

module.exports = classCheckEditor;